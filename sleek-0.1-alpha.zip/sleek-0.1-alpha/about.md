---
layout: page
title: About
permalink: /about/
---

Sleek is a modern Jekyll theme focused on speed performance & SEO best practices. You can find out more info about customizing your Jekyll theme, as well as basic Jekyll usage documentation at [jekyllrb.com](http://jekyllrb.com/) or simply read the guide on how to [get started](/getting-started)

You can find the source code for the Jekyll new theme at:
[sleek](https://github.com/janczizikow/sleek)

You can find the source code for Jekyll at
[jekyll](https://github.com/jekyll/jekyll)
